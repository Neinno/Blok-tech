# Blok-tech | Matching feature
Blok tech - CMD jaar 2 blok 4
Nigel Fijnheer


## Introduction
I am going to create a matching application that will be focused on cars. The your preferences will match an other users car. That gives you the opportunity to trade cars with each other. I will be focussing on creating only one feature of this application. The feature will be creating a post(car), and showing these on your profile.

## How to install
To get this project on your own computer you will have to clone this repository.

```
git clone https://github.com/Neinno/Blok-tech
```


Then install the npm packages with:

```
npm install
```


To start the project use:

```
node server.js
```


For the database i use MongoDB. To connect your own database change the information in the EXAMPLE.env file to your own information.


## Documentation
Navigate to the wiki for more information about the process of this project.



